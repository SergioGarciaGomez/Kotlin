package tema01.e02

/*
    @author Sergio García

    Ejercicio 04 - Tema 01

    Programa que muestre por pantalla todos los múltiplos de 3 en rango de 1 a 100
*/

fun main() {

    for (i:Int in 3..100 step 3) { print("$i ") }
}